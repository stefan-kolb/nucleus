var express = require('express');
var _ = require('underscore');
var app = express();

var config = require('./lib/config');
var words = require('./lib/words');

app.set('view engine', 'ejs');
app.set('view options', { layout: false });
app.use('/public', express.static('public'));

app.use(express.bodyParser());

app.use(app.router);

app.get('/', function (req, res) {
  res.render('index', { pattern: null });
});

app.post('/search', function (req, res) {
  var result = words.search(req.body.pattern).result;
  res.render('result', { words: result, pattern: req.body.pattern });
});

listen_on_port = process.env.OPENSHIFT_NODEJS_PORT || process.env.VCAP_APP_PORT || process.env.PORT || config.port;
listen_on_ip = process.env.OPENSHIFT_NODEJS_IP || "0.0.0.0";

app.listen(listen_on_port, listen_on_ip);
console.log("Listening on IP: " + listen_on_ip);
console.log("Listening on port: " + listen_on_port);
